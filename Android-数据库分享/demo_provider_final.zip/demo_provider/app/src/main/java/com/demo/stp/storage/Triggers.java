package com.demo.stp.storage;

public interface Triggers {
    String TABLE_UNKOWN = "triggers_table_unkown";
}
