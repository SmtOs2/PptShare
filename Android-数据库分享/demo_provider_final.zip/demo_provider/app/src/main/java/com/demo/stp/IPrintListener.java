package com.demo.stp;

public interface IPrintListener {
    void print();

    void onEnd();
}
