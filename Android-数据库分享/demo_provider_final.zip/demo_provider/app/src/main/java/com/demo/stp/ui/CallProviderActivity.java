package com.demo.stp.ui;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.View;

import com.demo.stp.BaseActivity;
import com.demo.stp.R;
import com.demo.stp.storage.DemoConstant;

import java.util.List;

public class CallProviderActivity extends BaseActivity {
    private static final String TAG = "CallProviderActivity";

    private BroadcastReceiver mReceiver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_provider);

        getContentResolver().registerContentObserver(DemoConstant.OtherConstant.getUri(), false, new ContentObserver(new Handler()) {
            @Override
            public void onChange(boolean selfChange) {
                Log.d(TAG, "onChange(boolean selfChange)");
            }

            @Override
            public void onChange(boolean selfChange, Uri uri) {
                String v = null;
                if (uri != null) {
                    v = uri.getQueryParameter("abc");
                    v = v + " " + uri.getQueryParameter("xyz");
                }
                Log.d(TAG, "onChange(boolean selfChange, Uri uri) v:" + v);
            }
        });

        mReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // TODO ; rece  intent.getExtras();
            }
        };
        IntentFilter filter = new IntentFilter("DemoConstant.OtherConstant.ACTION_PROVIDER_CALL_UI");
        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(mReceiver, filter);

        registerCallProvider("onCallDataClick");
    }

    public void onCallClick(View view) {
        getContentResolver().call(DemoConstant.BASE_URI, "onCallClick", null, null);
    }

    public void onSyncCallClick(View view) {
        Bundle extras = new Bundle();
        extras.putString("onCallDataClick", "onCallDataClick");
        getContentResolver().call(DemoConstant.BASE_URI, "onCallDataClick", null, extras);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
        unRegisterCallProvider("onCallDataClick");
    }

    @Override
    public Bundle callIn(String arg, Bundle extras) {
        String callData = extras.getString("onCallDataClick");
        Log.d(TAG, "callData:" + callData);
        return null;
    }
}
