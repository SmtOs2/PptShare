package com.demo.stp.service;

import android.app.IntentService;
import android.content.ContentProviderOperation;
import android.content.ContentValues;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.demo.stp.IPrintListener;
import com.demo.stp.storage.DemoConstant;
import com.demo.stp.storage.DemoConstant.TypeConstant;
import com.demo.stp.utils.SharePreUtils;
import com.demo.stp.utils.TestDataUtils;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public class DemoService extends IntentService {
    private static final String TAG = "DemoService";
    private static final AtomicBoolean INIT_DATA = new AtomicBoolean(false);

    public DemoService() {
        super(TAG);
        Log.d(TAG, "DemoService()");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "onHandleIntent action:" + action);
        if (TextUtils.equals(action, Actions.RECREATE_DB_DATA)) {
            initDbData();
        }
    }

    private void initDbData() {
        if (INIT_DATA.get()) {
            return;
        }

        if (INIT_DATA.compareAndSet(false, true) && !SharePreUtils.getBoolean(getApplicationContext(), "INIT_DATA")) {
            Log.d(TAG, "initDbData clearDb");
            //clear data
            TestDataUtils.clearDb(getApplicationContext());

            // add data
            addTypeData();
            addInfoData();
            addImageData();
            addVideoData();

            Log.d(TAG, "initDbData add finish");
            SharePreUtils.putBoolean(getApplicationContext(), "INIT_DATA", true);
        }
    }

    private void addTypeData() {
        ArrayList<ContentProviderOperation> list = new ArrayList<ContentProviderOperation>(5);

        list.add(ContentProviderOperation.newInsert(TypeConstant.getUri())
                .withValue(TypeConstant.TYPE_NAME, DemoConstant.TypeConstant.TYPE_UNKOWN)
                .withValue(TypeConstant.TYPE_VALUE, DemoConstant.FileType.TYPE_UNKOWN).build());
        list.add(ContentProviderOperation.newInsert(TypeConstant.getUri())
                .withValue(TypeConstant.TYPE_NAME, DemoConstant.TypeConstant.TYPE_DEFAULT)
                .withValue(TypeConstant.TYPE_VALUE, DemoConstant.FileType.TYPE_DEFAULT).build());
        list.add(ContentProviderOperation.newInsert(TypeConstant.getUri())
                .withValue(TypeConstant.TYPE_NAME, DemoConstant.TypeConstant.TYPE_IMAGE)
                .withValue(TypeConstant.TYPE_VALUE, DemoConstant.FileType.TYPE_IMAGE).build());
        list.add(ContentProviderOperation.newInsert(TypeConstant.getUri())
                .withValue(TypeConstant.TYPE_NAME, DemoConstant.TypeConstant.TYPE_VIDEO)
                .withValue(TypeConstant.TYPE_VALUE, DemoConstant.FileType.TYPE_VIDEO).build());
        list.add(ContentProviderOperation.newInsert(TypeConstant.getUri())
                .withValue(TypeConstant.TYPE_NAME, DemoConstant.TypeConstant.TYPE_OTHER)
                .withValue(TypeConstant.TYPE_VALUE, DemoConstant.FileType.TYPE_OTHER).build());
        try {
            getContentResolver().applyBatch(DemoConstant.CONTENT_AUTHORITY, list);
        } catch (Exception e) {
            Log.e(TAG, "addTypeData E:" + e);
        }
    }

    private void addInfoData() {
        TestDataUtils.testAddData(getApplicationContext(), null, 100);
    }

    private void addInfoData(int num, IPrintListener listener) {
        TestDataUtils.testAddData(getApplicationContext(), listener, num);
    }


    private void addImageData() {
        TestDataUtils.saveQueryImageData(getApplicationContext());
    }

    private void addVideoData() {
        TestDataUtils.saveQueryVideoData(getApplicationContext());
    }


}
