package com.demo.stp.storage.db;

import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.OperationApplicationException;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.demo.stp.DemoApplication;
import com.demo.stp.storage.DemoConstant;
import com.demo.stp.storage.Tables;

import java.util.ArrayList;

public class DemoProvider extends ContentProvider {
    private static final String TAG = "DemoProvider";
    private static final UriMatcher sUriMatcher = buildUriMatcher();

    private static final int FILE_INFO = 100;
    private static final int FILE_TYPE = FILE_INFO + 1;
    private static final int FILE_IMAGE = FILE_TYPE + 1;
    private static final int FILE_VIDEO = FILE_IMAGE + 1;
    private static final int FILE_OTHER = FILE_VIDEO + 1;

    private static UriMatcher buildUriMatcher() {
        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = DemoConstant.CONTENT_AUTHORITY;

        matcher.addURI(authority, DemoConstant.PATH_FILE_INFO, FILE_INFO);
        matcher.addURI(authority, DemoConstant.PATH_FILE_TYPE, FILE_TYPE);
        matcher.addURI(authority, DemoConstant.PATH_FILE_IMAGE, FILE_IMAGE);
        matcher.addURI(authority, DemoConstant.PATH_FILE_VIDEO, FILE_VIDEO);
        matcher.addURI(authority, DemoConstant.PATH_FILE_OTHER, FILE_OTHER);
        return matcher;
    }


    private DemoSqLiteHelper mHelper;

    @Override
    public boolean onCreate() {
        mHelper = new DemoSqLiteHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        final SQLiteDatabase db = mHelper.getReadableDatabase();
        final SelectionBuilder builder = buildSimpleSelection(uri);
        final Cursor cursor = builder.where(selection, selectionArgs).query(db, projection, sortOrder);

//        TODO may be user notify
//        if (cursor != null) {
//            cursor.getCount();
//            cursor.setNotificationUri(getContext().getContentResolver(), uri);
//        }

        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        String tableName = getTabName(uri);
        SQLiteDatabase db = mHelper.getWritableDatabase();
        final long result = db.insert(tableName, null, values);
        if (result > 0L) {
            onInsertNotify(uri, values);
            return ContentUris.withAppendedId(uri, result);
        }
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        final SQLiteDatabase db = mHelper.getWritableDatabase();
        final SelectionBuilder builder = buildSimpleSelection(uri);
        final int retVal = builder.where(selection, selectionArgs).delete(db);

        if (retVal > 0) {
            onDeleteNotify(uri);
        }

        return retVal;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        final SQLiteDatabase db = mHelper.getWritableDatabase();
        final SelectionBuilder builder = buildSimpleSelection(uri);
        final int retVal = builder.where(selection, selectionArgs).update(db, values);

        if (retVal > 0) {
            onUpdateNotify(uri, values);
        }

        return retVal;
    }

    @Override
    public ContentProviderResult[] applyBatch(ArrayList<ContentProviderOperation> operations) throws OperationApplicationException {
        final SQLiteDatabase db = mHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentProviderResult[] results = super.applyBatch(operations);
            db.setTransactionSuccessful();
            return results;
        } finally {
            db.endTransaction();
        }
    }


    private String getTabName(Uri uri) {
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case FILE_INFO:
                return Tables.FILE_INFO;
            case FILE_TYPE:
                return Tables.FILE_TYPE;
            case FILE_IMAGE:
                return Tables.FILE_IMAGE;
            case FILE_VIDEO:
                return Tables.FILE_VIDEO;
            case FILE_OTHER:
                return Tables.FILE_TEST_OTHER;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
    }


    private SelectionBuilder buildSimpleSelection(Uri uri) {
        final SelectionBuilder builder = new SelectionBuilder();
        final int match = sUriMatcher.match(uri);
        switch (match) {
            case FILE_INFO:
                return builder.table(Tables.FILE_INFO);
            case FILE_TYPE:
                return builder.table(Tables.FILE_TYPE);
            case FILE_IMAGE:
                return builder.table(Tables.FILE_IMAGE);
            case FILE_VIDEO:
                return builder.table(Tables.FILE_VIDEO);
            case FILE_OTHER:
                return builder.table(Tables.FILE_TEST_OTHER);
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
    }


    private void notify(Uri uri) {
        Context context = getContext();
        Log.d(TAG, "final notify uri:" + uri + " context:" + context);
        if (context == null) {
            return;
        }

        context.getContentResolver().notifyChange(uri, null, false);
    }

    public void onInsertNotify(Uri uri, ContentValues values) {
        notify(uri);
    }

    public void onUpdateNotify(Uri uri, ContentValues values) {
        notify(uri);
    }

    public void onDeleteNotify(Uri uri) {
        notify(uri);
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        //async notify
        // notify 1
        Uri rootUri = DemoConstant.OtherConstant.getUri();
        notify(rootUri.buildUpon().appendQueryParameter("abc", "123").appendQueryParameter("xyz", "456").build());

        //async notify 2
        Intent intent = new Intent(DemoConstant.OtherConstant.ACTION_PROVIDER_CALL_UI);
        intent.putExtra("callIn", "callIn");
        LocalBroadcastManager.getInstance(getContext()).sendBroadcast(intent);

        // sync notify
        return DemoApplication.getDemoApp().notifyCall(method, arg, extras);
    }
}
