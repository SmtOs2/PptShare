package com.demo.stp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.demo.stp.comm.ISyncProviderListener;

@SuppressLint("Registered")
public class BaseActivity extends Activity implements ISyncProviderListener {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Bundle callIn(String arg, Bundle extras) {
        return null;
    }

    /**
     * need re write callIn method
     *
     * @param method
     */
    protected void registerCallProvider(String method) {
        DemoApplication.getDemoApp().addListener(method, this);
    }

    /**
     *
     * @param method
     */
    protected void unRegisterCallProvider(String method) {
        DemoApplication.getDemoApp().removeListener(method);
    }
}
