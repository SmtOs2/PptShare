package com.demo.stp.comm;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public class SyncProviderCallManager {
    private final Map<String, SyncProviderListener> mListeners;

    public SyncProviderCallManager() {
        mListeners = new HashMap<String, SyncProviderListener>();
    }

    public void addListener(@NonNull String method, @NonNull ISyncProviderListener listener) {
        mListeners.put(method, new SyncProviderListener(listener));
    }

    public Bundle notifyCall(@NonNull String method, String arg, Bundle extras) {
        if (mListeners.isEmpty()) {
            return null;
        }

        for (Map.Entry<String, SyncProviderListener> entry : mListeners.entrySet()) {
            if (TextUtils.equals(method, entry.getKey())) {
                final SyncProviderListener reference = entry.getValue();
                if (reference == null) {
                    removeListener(method);
                } else {
                    final ISyncProviderListener listener = reference.get();
                    if (listener == null) {
                        removeListener(method);
                    } else {
                        return listener.callIn(arg, extras);
                    }
                }
            }
        }
        return null;
    }

    public void removeListener(String method) {
        if (mListeners.isEmpty()) {
            return;
        }

        mListeners.remove(method);
    }

    private static class SyncProviderListener {
        private final WeakReference<ISyncProviderListener> mWeakReference;

        private SyncProviderListener(ISyncProviderListener listener) {
            mWeakReference = new WeakReference<ISyncProviderListener>(listener);
        }

        private ISyncProviderListener get() {
            return mWeakReference.get();
        }
    }
}
