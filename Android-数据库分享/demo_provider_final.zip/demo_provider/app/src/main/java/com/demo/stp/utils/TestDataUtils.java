package com.demo.stp.utils;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.util.Log;

import com.demo.stp.IPrintListener;
import com.demo.stp.storage.DemoConstant;

import java.util.ArrayList;
import java.util.Random;
import java.util.UUID;

public final class TestDataUtils {
    private static final String TAG = "TestDataUtils";
    private static final int DEFAULT_NUM = 5000;

    private static final int[] fileArr = new int[]{DemoConstant.FileType.TYPE_UNKOWN, DemoConstant.FileType.TYPE_DEFAULT,
            DemoConstant.FileType.TYPE_IMAGE, DemoConstant.FileType.TYPE_VIDEO,
            DemoConstant.FileType.TYPE_OTHER};

    public static void testAddData(@NonNull final Context context) {
        testAddData(context, null, DEFAULT_NUM);
    }

    private static ThreadLocal<Long> mThreadTime = new ThreadLocal<Long>() {
        @Override
        protected Long initialValue() {
            return -1L;
        }
    };

    public static void testAddData(@NonNull final Context context, IPrintListener printListener, int num) {
        final ArrayList<ContentProviderOperation> dataList = new ArrayList<ContentProviderOperation>();
        try {
            for (int i = 1; i < num; i++) {
                if (dataList.size() > 300) {
                    applyBatch(context, dataList);
                    dataList.clear();

                    if(printListener != null) {
                        printListener.print();
                    }
                }

                long fileSize = getRandLong();
                int fileType = fileArr[i % fileArr.length];
                long localT = fileSize + i * 345;
                long lastMT = localT + i * 564;
                String fileId = UUID.randomUUID().toString();
                String name = "test" + getRandInt((i * 44) % Integer.MAX_VALUE) + i;
                String url = "http://wiki.smartisan.cn/doku.php/" + (localT / i == 0 ? "" : localT / i);
                String path = "/" + name;
                String fileMd5 = Md5Util.byteToHexString((url + path).getBytes());

                ContentProviderOperation operation = ContentProviderOperation.newInsert(DemoConstant.InfoConstant.getUri())
                        .withValue(DemoConstant.InfoConstant.FILE_ID, fileId)
                        .withValue(DemoConstant.InfoConstant.FILE_TYPE, fileType)
                        .withValue(DemoConstant.InfoConstant.FILE_MD5, fileMd5)
                        .withValue(DemoConstant.InfoConstant.FILE_NAME, name)
                        .withValue(DemoConstant.InfoConstant.FILE_PATH, path)
                        .withValue(DemoConstant.InfoConstant.FILE_URL, url)
                        .withValue(DemoConstant.InfoConstant.FILE_SIZE, fileSize)
                        .withValue(DemoConstant.InfoConstant.LAST_MODIFY_TIME, lastMT)
                        .withValue(DemoConstant.InfoConstant.LOCAL_TIME, localT)
                        .build();

                dataList.add(operation);
            }

            if (!dataList.isEmpty()) {
                applyBatch(context, dataList);
            }

            if (printListener != null) {
                printListener.onEnd();
            }
        } catch (Exception e) {
            Log.d(TAG, "testAddData E:" + e);
            dataList.clear();
        } finally {
            dataList.clear();
        }
    }

    private static int getRandInt(int max) {
        Random ra = new Random();
        return ra.nextInt(max);
    }

    private static long getRandLong() {
        Random ra = new Random();
        return ra.nextLong();
    }

    public static void testQueryImageData(@NonNull Context context) {
        testQueryImageData(context, null);
    }


    public static void testQueryImageData(@NonNull Context context, final IPrintListener listener) {
        Cursor cursor = context.getContentResolver().query(DemoConstant.InfoConstant.getUri(),
                DemoConstant.InfoConstant.Query.PROJECTION, DemoConstant.InfoConstant.FILE_TYPE + "=?",
                new String[]{String.valueOf(DemoConstant.FileType.TYPE_IMAGE)}, null);

        try {
            if (mThreadTime.get() < 0) {
                mThreadTime.set(System.currentTimeMillis());
            }
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    if (listener != null) {
                        long curTime = System.currentTimeMillis();
                        if (curTime - mThreadTime.get() > 500) {
                            listener.print();
                            mThreadTime.set(curTime);
                        }
                    }
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public static void saveQueryImageData(@NonNull Context context) {
        saveQueryImageData(context, null);
    }

    public static void saveQueryImageData(@NonNull Context context, IPrintListener listener) {
        Cursor cursor = context.getContentResolver().query(DemoConstant.InfoConstant.getUri(),
                DemoConstant.InfoConstant.Query.PROJECTION, DemoConstant.InfoConstant.FILE_TYPE + "=?",
                new String[]{String.valueOf(DemoConstant.FileType.TYPE_IMAGE)}, null);

        try {
            final ArrayList<ContentProviderOperation> imageDataList = new ArrayList<ContentProviderOperation>();
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    if (imageDataList.size() > 200) {
                        applyBatch(context, imageDataList);
                        imageDataList.clear();
                        if (listener != null) {
                            listener.print();
                        }
                    }


                    String sourId = cursor.getString(DemoConstant.InfoConstant.Query.FILE_ID);
                    String fileThum = String.valueOf(sourId.hashCode());
                    String fileCloudId = sourId;
                    long fileSize = cursor.getLong(DemoConstant.InfoConstant.Query.FILE_SIZE);

                    ContentProviderOperation operation = ContentProviderOperation.newInsert(DemoConstant.ImageConstant.getUri())
                            .withValue(DemoConstant.ImageConstant.FILE_SOURCE_ID, sourId)
                            .withValue(DemoConstant.ImageConstant.FILE_THUM, fileThum)
                            .withValue(DemoConstant.ImageConstant.FILE_CLOULD_ID, fileCloudId)
                            .withValue(DemoConstant.ImageConstant.FILE_SIZE, fileSize)
                            .build();

                    imageDataList.add(operation);
                } while (cursor.moveToNext());
            }

            if (!imageDataList.isEmpty()) {
                applyBatch(context, imageDataList);
            }

            if (listener != null) {
                listener.onEnd();
            }
        } catch (Exception e) {
            Log.d(TAG, "saveQueryImageData E:" + e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static void applyBatch(Context context, ArrayList<ContentProviderOperation> list) {
        try {
            context.getContentResolver().applyBatch(DemoConstant.CONTENT_AUTHORITY, list);
        } catch (Exception e) {
        }
    }

    public static void saveQueryVideoData(@NonNull Context context) {
        saveQueryVideoData(context, null);
    }

    public static void saveQueryVideoData(@NonNull Context context, IPrintListener listener) {
        Cursor cursor = context.getContentResolver().query(DemoConstant.InfoConstant.getUri(),
                DemoConstant.InfoConstant.Query.PROJECTION, DemoConstant.InfoConstant.FILE_TYPE + "=?",
                new String[]{String.valueOf(DemoConstant.FileType.TYPE_VIDEO)}, null);

        try {
            if (mThreadTime.get() < 0) {
                mThreadTime.set(System.currentTimeMillis());
            }
            final ArrayList<ContentProviderOperation> videoDataList = new ArrayList<ContentProviderOperation>();
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    if (videoDataList.size() > 200) {
                        applyBatch(context, videoDataList);
                        videoDataList.clear();
                        if (listener != null) {
                            listener.print();
                        }
                    }


                    String sourId = cursor.getString(DemoConstant.InfoConstant.Query.FILE_ID);
                    String fileThum = String.valueOf(sourId.hashCode());
                    String fileCloudId = sourId;
                    long fileSize = cursor.getLong(DemoConstant.InfoConstant.Query.FILE_SIZE);

                    ContentProviderOperation operation = ContentProviderOperation.newInsert(DemoConstant.VideoConstant.getUri())
                            .withValue(DemoConstant.VideoConstant.FILE_SOURCE_ID, sourId)
                            .withValue(DemoConstant.VideoConstant.FILE_THUM, fileThum)
                            .withValue(DemoConstant.VideoConstant.FILE_CLOULD_ID, fileCloudId)
                            .withValue(DemoConstant.VideoConstant.FILE_SIZE, fileSize)
                            .build();

                    videoDataList.add(operation);
                } while (cursor.moveToNext());
            }

            if (!videoDataList.isEmpty()) {
                applyBatch(context, videoDataList);
            }

            if (listener != null) {
                listener.onEnd();
            }
        } catch (Exception e) {
            Log.d(TAG, "saveQueryVideoData E:" + e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public static void clearDb(@NonNull Context context) {
        context.getContentResolver().delete(DemoConstant.TypeConstant.getUri(), null, null);
        context.getContentResolver().delete(DemoConstant.InfoConstant.getUri(), null, null);
        context.getContentResolver().delete(DemoConstant.ImageConstant.getUri(), null, null);
        context.getContentResolver().delete(DemoConstant.VideoConstant.getUri(), null, null);
    }

    public static void addOther(@NonNull Context context, IPrintListener listener, int num) {
    }

}
