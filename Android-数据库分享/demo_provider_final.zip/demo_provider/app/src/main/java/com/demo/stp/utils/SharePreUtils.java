package com.demo.stp.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharePreUtils {
    private static final String PRE_NAME = "demo_config";
    private static SharedPreferences mPre;

    private static void init(Context context) {
        mPre = context.getSharedPreferences(PRE_NAME, Context.MODE_PRIVATE);
    }

    public static void putBoolean(Context context, String key, boolean val) {
        if (mPre == null) {
            init(context);
        }

        mPre.edit().putBoolean(key, val).apply();
    }

    public static boolean getBoolean(Context context, String key) {
        if (mPre == null) {
            init(context);
        }

        return mPre.getBoolean(key, false);
    }
}
