package com.demo.stp;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;

import com.demo.stp.comm.ISyncProviderListener;
import com.demo.stp.comm.SyncProviderCallManager;
import com.demo.stp.service.Actions;
import com.demo.stp.service.DemoService;

public class DemoApplication extends Application {
    private static final String TAG = "DemoApplication";
    private SyncProviderCallManager mCallManager;
    private static DemoApplication mApplication;

    @Override
    public void onCreate() {
        super.onCreate();
        mApplication = this;

        Log.d(TAG, "DemoApplication onCreate");
        Intent intent = new Intent(getApplicationContext(), DemoService.class);
        intent.setAction(Actions.RECREATE_DB_DATA);
        startService(intent);
    }

    public void addListener(@NonNull String method, @NonNull ISyncProviderListener listener) {
        if (mCallManager == null) {
            mCallManager = new SyncProviderCallManager();
        }
        mCallManager.addListener(method, listener);
    }

    public static DemoApplication getDemoApp() {
        return mApplication;
    }

    public Bundle notifyCall(@NonNull String method, String arg, Bundle extras) {
        if (mCallManager == null) {
            return null;
        }

        return mCallManager.notifyCall(method, arg, extras);
    }

    public void removeListener(String method) {
        if (mCallManager == null) {
            return;
        }

        mCallManager.removeListener(method);
    }
}
