package com.demo.stp.storage.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.demo.stp.storage.DemoColumn;
import com.demo.stp.storage.DemoConstant;
import com.demo.stp.storage.DemoConstant.FileImageColumn;
import com.demo.stp.storage.DemoConstant.FileInoColumn;
import com.demo.stp.storage.DemoConstant.FileTypeColumn;
import com.demo.stp.storage.DemoConstant.FileVideoColumn;
import com.demo.stp.storage.Tables;
import com.demo.stp.storage.Triggers;

public class DemoSqLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "demo_stp.db";

    private static final int DATABASE_VERSION = 1;

    public DemoSqLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTab(db);

        // create Index
        // create Trigger
        // create View
        createTrigger(db);
    }

    private void createTrigger(SQLiteDatabase db) {
        String sql = "CREATE TRIGGER IF NOT EXISTS " + Triggers.TABLE_UNKOWN + " AFTER INSERT ON file_info FOR EACH ROW WHEN (" +
                " new." + FileInoColumn.FILE_TYPE + "=" + DemoConstant.FileType.TYPE_UNKOWN + ")" +
                " BEGIN INSERT INTO " + Tables.FILE_UNKOWN + " (" + DemoConstant.FileUnkownColumn.FILE_SOURCE_ID + "," + DemoConstant.FileUnkownColumn.FILE_SIZE + "," + DemoConstant.FileUnkownColumn.FILE_NAME
                + ") VALUES (new." + DemoConstant.FileUnkownColumn.FILE_ID + ",new." + DemoConstant.FileUnkownColumn.FILE_SIZE + ",new." + DemoConstant.FileUnkownColumn.FILE_NAME + "); "
                + " END;";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    private void createTab(SQLiteDatabase db) {
        // create type table
        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_TYPE
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + FileTypeColumn.TYPE_NAME + " INTEGER, "
                + FileTypeColumn.TYPE_VALUE + " INTEGER)");

        // create file info table
        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_INFO
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + DemoColumn.FILE_ID + " TEXT, "
                + DemoColumn.FILE_MD5 + " TEXT, "
                + DemoColumn.FILE_NAME + " TEXT, "
                + FileInoColumn.FILE_PATH + " TEXT, "
                + FileInoColumn.FILE_URL + " TEXT, "
                + DemoColumn.FILE_SIZE + " INTEGER, "
                + FileInoColumn.FILE_TYPE + " INTEGER, "
                + FileInoColumn.LAST_MODIFY_TIME + " INTEGER, "
                + FileInoColumn.LOCAL_TIME + " INTEGER, "
                + " UNIQUE(" + FileTypeColumn.FILE_ID + ") "
                + "ON CONFLICT REPLACE)");

        // create image file table
        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_IMAGE
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + FileImageColumn.FILE_SOURCE_ID + " TEXT, "
                + FileImageColumn.FILE_THUM + " TEXT, "
                + FileImageColumn.FILE_CLOULD_ID + " TEXT, "
                + FileImageColumn.FILE_SIZE + " INTEGER, "
                + " UNIQUE(" + FileImageColumn.FILE_SOURCE_ID + ") "
                + "ON CONFLICT REPLACE)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_VIDEO
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + FileVideoColumn.FILE_SOURCE_ID + " TEXT, "
                + FileVideoColumn.FILE_THUM + " TEXT, "
                + FileVideoColumn.FILE_CLOULD_ID + " TEXT, "
                + FileVideoColumn.FILE_SIZE + " INTEGER, "
                + " UNIQUE(" + FileVideoColumn.FILE_SOURCE_ID + ") "
                + "ON CONFLICT REPLACE)");


        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_TEST_OTHER
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + DemoConstant.FileOtherColumn.FILE_OTHER + " TEXT, "
                + DemoConstant.FileOtherColumn.FILE_OTHER_1 + " TEXT, "
                + DemoConstant.FileOtherColumn.FILE_OTHER_2 + " TEXT, "
                + DemoConstant.FileOtherColumn.FILE_OTHER_3 + " TEXT, "
                + DemoConstant.FileOtherColumn.FILE_OTHER_4 + " TEXT, "
                + " UNIQUE(" + DemoConstant.FileOtherColumn._ID + ") "
                + "ON CONFLICT REPLACE)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + Tables.FILE_UNKOWN
                + "(" + DemoColumn._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + DemoConstant.FileUnkownColumn.FILE_SOURCE_ID + " TEXT, "
                + DemoConstant.FileUnkownColumn.FILE_NAME + " TEXT,"
                + DemoConstant.FileUnkownColumn.FILE_SIZE + " TEXT)");

    }
}
