package com.demo.stp.service;

public interface Actions {
    String RECREATE_DB_DATA = "com.demo.stp.service.recreate_db_data";
}
