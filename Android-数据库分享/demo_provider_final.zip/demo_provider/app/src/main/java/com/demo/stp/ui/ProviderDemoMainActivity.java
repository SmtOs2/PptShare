package com.demo.stp.ui;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.demo.stp.BaseActivity;
import com.demo.stp.R;
import com.demo.stp.storage.DemoConstant;

public class ProviderDemoMainActivity extends BaseActivity {

    private static final String TAG = "ProviderDemoMainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_demo_main);
    }


    public void startActivityClick(View view) {
        startActivity(new Intent(this, CallProviderActivity.class));
    }

    ThreadLocal<Integer> mT = new ThreadLocal<Integer>();

    int i = 0;

    public void onTwoInsertClick(View view) {
        getContentResolver().delete(DemoConstant.OtherConstant.getUri(), null, null);
        i = 0;
        try {
            for (int ii = 0; ii < 200; ii++) {
                i++;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(10L);
                            ContentValues values = new ContentValues(3);
                            values.put(DemoConstant.OtherConstant.FILE_OTHER, "other_1");
                            values.put(DemoConstant.OtherConstant.FILE_OTHER_1, "other_1-" + i);
                            values.put(DemoConstant.OtherConstant.FILE_OTHER_2, "other_1-" + i + ":" + Thread.currentThread().toString());
                            getContentResolver().insert(DemoConstant.OtherConstant.getUri(), values);
                            Log.d(TAG, "onTwoInsertClick_1 print curThread:" + Thread.currentThread());
                        } catch (Exception e) {

                        }

                    }
                }).start();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(10L);
                            ContentValues values = new ContentValues(3);
                            values.put(DemoConstant.OtherConstant.FILE_OTHER, "other_1_1");
                            values.put(DemoConstant.OtherConstant.FILE_OTHER_1, "other_1_1-" + i);
                            values.put(DemoConstant.OtherConstant.FILE_OTHER_2, "other_1_1-" + i + ":" + Thread.currentThread().toString());
                            getContentResolver().insert(DemoConstant.OtherConstant.getUri(), values);
                            Log.d(TAG, "onTwoInsertClick_1_1----- print curThread:" + Thread.currentThread());
                        } catch (Exception e) {

                        }
                    }
                }).start();
            }
        } catch (Exception e) {

        }

        Log.d(TAG, "onTwoInsertClick 1 print end");
    }

    public void onOneInsertOneQueryClick(View view) {
        i = 0;
        try {
            for (int ii = 1000; ii < 1200; ii++) {
                i++;

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(11L);
                        } catch (Exception e) {

                        }
                        ContentValues values = new ContentValues(3);
                        values.put(DemoConstant.OtherConstant.FILE_OTHER, "other_x");
                        values.put(DemoConstant.OtherConstant.FILE_OTHER_1, "other_x-" + i);
                        values.put(DemoConstant.OtherConstant.FILE_OTHER_2, "other_x-" + i + ":" + Thread.currentThread().toString());
                        getContentResolver().insert(DemoConstant.OtherConstant.getUri(), values);
                        Log.d(TAG, "onOneInsertOneQueryClick insert print curThread:" + Thread.currentThread());
                    }
                }).start();

                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        Cursor cursor = null;
                        try {
                            cursor = getContentResolver().query(DemoConstant.OtherConstant.getUri(), null,
                                    DemoConstant.OtherConstant.FILE_OTHER + "=?",
                                    new String[]{"other_x"}, null);
                            Thread.sleep(11L);
                            if (cursor != null && cursor.moveToFirst()) {
                                cursor.getString(1);
                            }
                            Log.d(TAG, "onOneInsertOneQueryClick query print curThread:" + Thread.currentThread() + " count:" + (cursor == null ? null : cursor.getCount()));
                        } catch (Exception e) {

                        } finally {
                            if (cursor != null) {
                                cursor.close();
                            }
                        }

                    }
                }).start();
            }
        } catch (Exception e) {

        }
    }

    public void onTwoQueryClick(View view) {
        i = 0;
        try {
            for (int ii = 0; ii < 1; ii++) {
                i++;

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Cursor cursor = null;
                        try {
                            cursor = getContentResolver().query(DemoConstant.OtherConstant.getUri(), null, null, null, null);
                            Thread.sleep(50L);
                            if (cursor != null && cursor.moveToFirst()) {
                                cursor.getString(1);
                            }
                            Log.d(TAG, "onTwoQueryClick other query print curThread:" + Thread.currentThread() + " --size--" + (cursor == null ? null : cursor.getCount()));
                        } catch (Exception e) {

                        } finally {
                            if (cursor != null) {
                                cursor.close();
                            }
                        }
                    }
                }).start();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Cursor cursor = null;
                        try {
                            cursor = getContentResolver().query(DemoConstant.InfoConstant.getUri(), null, null, null, null);
                            Thread.sleep(50L);
                            if (cursor != null && cursor.moveToFirst()) {
                                cursor.getString(1);
                            }
                            Log.d(TAG, "onTwoQueryClick info query print curThread:" + Thread.currentThread() + " --size--" + (cursor == null ? null : cursor.getCount()));
                        } catch (Exception e) {

                        } finally {
                            if (cursor != null) {
                                cursor.close();
                            }
                        }
                    }
                }).start();
            }
        } catch (Exception e) {

        }


    }

    public void onOneQueryOneInsertClick(View view) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(11);

                    ContentValues values = new ContentValues(3);
                    values.put(DemoConstant.OtherConstant.FILE_OTHER, "other_test");
                    values.put(DemoConstant.OtherConstant.FILE_OTHER_1, "other_test-" + i);
                    values.put(DemoConstant.OtherConstant.FILE_OTHER_2, "other_test-" + i + ":" + Thread.currentThread().toString());
                    getContentResolver().insert(DemoConstant.OtherConstant.getUri(), values);
                } catch (Exception e) {

                }
            }
        }).start();


        new Thread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    Thread.sleep(8);
                    cursor = getContentResolver().query(DemoConstant.InfoConstant.getUri(), null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        cursor.getString(1);
                    }
                    Log.d(TAG, "onOneQueryOneInsertClick info query print curThread:" + Thread.currentThread() + " --size--" + (cursor == null ? null : cursor.getCount()));
                } catch (Exception e) {

                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        }).start();
    }

}
