package com.demo.stp.comm;

import android.os.Bundle;

public interface ISyncProviderListener {
    Bundle callIn(String arg, Bundle extras);
}
