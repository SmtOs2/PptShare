package com.demo.stp.storage;

import android.net.Uri;

public class DemoConstant {
    public static final String CONTENT_AUTHORITY = "com.demo.stp.storage.db.demo_provider";

    public static Uri BASE_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_FILE_INFO = "path_file_info";

    public static final String PATH_FILE_IMAGE = "path_file_image";

    public static final String PATH_FILE_VIDEO = "path_file_video";

    public static final String PATH_FILE_TYPE = "path_file_type";

    public static final String PATH_FILE_OTHER = "path_file_other";

    public interface FileType {
        int TYPE_UNKOWN = -1;
        int TYPE_DEFAULT = 0;
        int TYPE_IMAGE = 1;
        int TYPE_VIDEO = 2;
        int TYPE_OTHER = 3;
    }


    public interface FileInoColumn extends DemoColumn {
        String LOCAL_TIME = "local_time";
        String LAST_MODIFY_TIME = "last_modify_time";
        String FILE_TYPE = "file_type";
        String FILE_URL = "file_url";
    }

    public interface FileImageColumn extends DemoColumn {
        String FILE_SOURCE_ID = "file_source_id";
        String FILE_THUM = "file_thum";
        String FILE_CLOULD_ID = "file_clould_id";
        String FILE_URL = "file_url";
    }

    public interface FileVideoColumn extends DemoColumn {
        String FILE_SOURCE_ID = "file_source_id";
        String FILE_THUM = "file_thum";
        String FILE_CLOULD_ID = "file_clould_id";
        String FILE_URL = "file_url";
    }

    public interface FileOtherColumn extends DemoColumn {
        String FILE_OTHER = "file_other";
        String FILE_OTHER_1 = "file_other_1";
        String FILE_OTHER_2 = "file_other_2";
        String FILE_OTHER_3 = "file_other_3";
        String FILE_OTHER_4 = "file_other_4";
    }

    public interface FileUnkownColumn extends DemoColumn {
        String FILE_SOURCE_ID = "file_source_id";
        String FILE_NAME = "file_name";
        String FILE_SIZE = "file_size";
    }

    public interface FileTypeColumn extends DemoColumn {
        String TYPE_NAME = "type_name";
        String TYPE_VALUE = "type_value";
    }

    public static class InfoConstant implements FileInoColumn {
        public static final Uri getUri() {
            return BASE_URI.buildUpon().appendPath(PATH_FILE_INFO).build();
        }

        public static interface Query extends DemoColumn {
            String[] PROJECTION = {_ID, DemoColumn.FILE_ID, DemoColumn.FILE_MD5, DemoColumn.FILE_NAME,
                    FileInoColumn.FILE_PATH, FileInoColumn.FILE_URL, DemoColumn.FILE_SIZE,
                    FileInoColumn.FILE_TYPE, FileInoColumn.LAST_MODIFY_TIME, FileInoColumn.LOCAL_TIME};

            int ID = 0;
            int FILE_ID = 1;
            int FILE_MD5 = 2;
            int FILE_NAME = 3;
            int FILE_PATH = 4;
            int FILE_URL = 5;
            int FILE_SIZE = 6;
            int FILE_TYPE = 7;
            int LAST_MODIFY_TIME = 8;
            int LOCAL_TIME = 9;
        }
    }

    public static class TypeConstant implements FileTypeColumn {
        public static final String TYPE_UNKOWN = "type_unkown";
        public static final  String TYPE_DEFAULT = "type_default";
        public static final String TYPE_IMAGE = "type_image";
        public static final String TYPE_VIDEO = "type_video";
        public static final String TYPE_OTHER = "type_other";

        public static final Uri getUri() {
            return BASE_URI.buildUpon().appendPath(PATH_FILE_TYPE).build();
        }

        public interface Query extends DemoColumn {
            String[] PROJECTION = {_ID, FileTypeColumn.TYPE_NAME, FileTypeColumn.TYPE_VALUE};

            int id = 0;
            int TYPE_NAME = 1;
            int TYPE_VALUE = 2;
        }
    }


    public static class ImageConstant implements FileImageColumn {
        public static final Uri getUri() {
            return BASE_URI.buildUpon().appendPath(PATH_FILE_IMAGE).build();
        }

        public interface Query extends DemoColumn {
            String[] PROJECTION = {_ID, FileImageColumn.FILE_SOURCE_ID, FileImageColumn.FILE_THUM,
                    FileImageColumn.FILE_CLOULD_ID, FileImageColumn.FILE_SIZE};

            int ID = 0;
            int FILE_SOURCE_ID = 1;
            int FILE_THUM = 2;
            int FILE_CLOULD_ID = 3;
            int FILE_SIZE = 4;
        }
    }

    public static class VideoConstant implements FileVideoColumn {
        public static final Uri getUri() {
            return BASE_URI.buildUpon().appendPath(PATH_FILE_VIDEO).build();
        }

        public interface Query extends DemoColumn {
            String[] PROJECTION = {_ID, FileVideoColumn.FILE_SOURCE_ID, FileVideoColumn.FILE_THUM,
                    FileVideoColumn.FILE_CLOULD_ID, FileVideoColumn.FILE_SIZE};

            int ID = 0;
            int FILE_SOURCE_ID = 1;
            int FILE_THUM = 2;
            int FILE_CLOULD_ID = 3;
            int FILE_SIZE = 4;
        }
    }


    public static class OtherConstant implements FileOtherColumn{
        public static final Uri getUri() {
            return BASE_URI.buildUpon().appendPath(PATH_FILE_OTHER).build();
        }

        public static final String ACTION_PROVIDER_CALL_UI = "com.demo.stp.storage.ACTION_PROVIDER_CALL_UI";
    }
}
