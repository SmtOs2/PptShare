package com.demo.stp.storage;

public interface Tables {
    String FILE_INFO = "file_info";

    String FILE_IMAGE = "file_image";

    String FILE_VIDEO = "file_video";

    String FILE_TYPE = "file_type";

    String FILE_TEST_OTHER = "file_test_other";

    String FILE_UNKOWN = "file_unkown";
}
