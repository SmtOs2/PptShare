package com.demo.stp.storage;

public interface DemoColumn {
    String _ID = "_id";

    String FILE_NAME = "file_name";

    String FILE_PATH = "file_path";

    String FILE_MD5 = "file_md5";

    String FILE_SIZE = "file_size";

    String FILE_ID = "file_id";
}
